﻿use DatGiaoHang
--1. View danh sách đơn đặt hàng kèm thông tin nhà cung cấp
CREATE VIEW v_DonDatHang_NhaCungCap AS
SELECT ddh.SoDDH, ddh.NgayDat, ncc.TenNCC, ncc.DiaChi
FROM DonDatHang ddh
INNER JOIN NhaCungCap ncc ON ddh.MaNCC = ncc.MaNCC;
-- Lọc danh sách đơn đặt hàng và thông tin nhà cung cấp

--2. View tổng số lượng đặt theo từng mặt hàng
CREATE VIEW v_TongSoLuongDat_MatHang AS
SELECT mh.MaMH, mh.TenMH, SUM(ctdh.SoLuongDat) AS TongSoLuongDat
FROM ChiTietDatHang ctdh
INNER JOIN MatHang mh ON ctdh.MaMH = mh.MaMH
GROUP BY mh.MaMH, mh.TenMH;
--Tổng hợp số lượng đặt của từng mặt hàng

--3. View danh sách mặt hàng chưa từng được đặt
CREATE VIEW v_MatHang_ChuaDat AS
SELECT mh.MaMH, mh.TenMH
FROM MatHang mh
WHERE NOT EXISTS (
    SELECT 1 FROM ChiTietDatHang ctdh WHERE mh.MaMH = ctdh.MaMH
);
-- Lọc ra các mặt hàng chưa từng có trong đơn đặt hàng

--4. View đơn đặt hàng có tổng giá trị lớn nhất
CREATE VIEW v_DonDatHang_MaxValue AS
SELECT ddh.SoDDH, SUM(ctdh.SoLuongDat * ctdh.DonGiaDat) AS TongGiaTri
FROM DonDatHang ddh
INNER JOIN ChiTietDatHang ctdh ON ddh.SoDDH = ctdh.SoDDH
GROUP BY ddh.SoDDH
HAVING SUM(ctdh.SoLuongDat * ctdh.DonGiaDat) = (
    SELECT MAX(TongGiaTri)
    FROM (
        SELECT SUM(ctdh.SoLuongDat * ctdh.DonGiaDat) AS TongGiaTri
        FROM ChiTietDatHang ctdh
        GROUP BY ctdh.SoDDH
    ) AS Subquery
);
-- Xác định đơn đặt hàng có giá trị cao nhất

--5. View nhà cung cấp có số đơn hàng nhiều nhất
CREATE VIEW v_NCC_Top AS
SELECT ncc.MaNCC, ncc.TenNCC, COUNT(ddh.SoDDH) AS SoLuongDon
FROM NhaCungCap ncc
INNER JOIN DonDatHang ddh ON ncc.MaNCC = ddh.MaNCC
GROUP BY ncc.MaNCC, ncc.TenNCC
HAVING COUNT(ddh.SoDDH) = (
    SELECT MAX(SoLuongDon)
    FROM (
        SELECT COUNT(ddh.SoDDH) AS SoLuongDon
        FROM DonDatHang ddh
        GROUP BY ddh.MaNCC
    ) AS Subquery
);
--Tìm nhà cung cấp có nhiều đơn hàng nhất

--6. View danh sách đơn hàng chưa giao đủ
CREATE VIEW v_DonHang_ChuaGiaoDu AS
SELECT ddh.SoDDH, SUM(ctdh.SoLuongDat) AS TongSoLuongDat, 
       COALESCE(SUM(ctgh.SoLuongGiao), 0) AS TongSoLuongGiao
FROM DonDatHang ddh
INNER JOIN ChiTietDatHang ctdh ON ddh.SoDDH = ctdh.SoDDH
LEFT JOIN ChiTietGiaoHang ctgh ON ctdh.MaMH = ctgh.MaMH
GROUP BY ddh.SoDDH
HAVING COALESCE(SUM(ctgh.SoLuongGiao), 0) < SUM(ctdh.SoLuongDat);
--Tìm đơn hàng chưa giao đủ số lượng

--7. View tổng giá trị đơn hàng theo từng tháng
CREATE VIEW v_GiaTriDonHang_TheoThang AS
SELECT YEAR(ddh.NgayDat) AS Nam, MONTH(ddh.NgayDat) AS Thang, 
       SUM(ctdh.SoLuongDat * ctdh.DonGiaDat) AS TongGiaTri
FROM DonDatHang ddh
INNER JOIN ChiTietDatHang ctdh ON ddh.SoDDH = ctdh.SoDDH
GROUP BY YEAR(ddh.NgayDat), MONTH(ddh.NgayDat);
