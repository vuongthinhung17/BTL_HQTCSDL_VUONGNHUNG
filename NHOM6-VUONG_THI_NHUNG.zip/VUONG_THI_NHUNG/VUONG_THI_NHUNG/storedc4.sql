﻿USE DatGiaoHang;
GO

-- 1. Lấy danh sách tất cả đơn đặt hàng (Không tham số)
CREATE PROCEDURE sp_LayDanhSachDonHang
AS
BEGIN
    SELECT ddh.SoDDH, ddh.NgayDat, ncc.TenNCC
    FROM DonDatHang ddh
    INNER JOIN NhaCungCap ncc ON ddh.MaNCC = ncc.MaNCC;
END;
GO

-- 2. Lấy danh sách mặt hàng có số lượng đặt lớn hơn X (Có tham số)
CREATE PROCEDURE sp_LayMatHang_LonHon
    @SoLuongMin INT
AS
BEGIN
    SELECT mh.MaMH, mh.TenMH, SUM(ctdh.SoLuongDat) AS TongSoLuongDat
    FROM ChiTietDatHang ctdh
    INNER JOIN MatHang mh ON ctdh.MaMH = mh.MaMH
    GROUP BY mh.MaMH, mh.TenMH
    HAVING SUM(ctdh.SoLuongDat) > @SoLuongMin;
END;
GO

-- 3. Tìm đơn đặt hàng theo mã đơn (Có tham số)
CREATE PROCEDURE sp_TimDonHangTheoMa
    @SoDDH INT
AS
BEGIN
    SELECT * FROM DonDatHang WHERE SoDDH = @SoDDH;
END;
GO

-- 4. Thêm một nhà cung cấp mới (Có tham số)
CREATE PROCEDURE sp_ThemNhaCungCap
    @MaNCC INT,
    @TenNCC NVARCHAR(255),
    @DiaChi NVARCHAR(255)
AS
BEGIN
    INSERT INTO NhaCungCap (MaNCC, TenNCC, DiaChi)
    VALUES (@MaNCC, @TenNCC, @DiaChi);
END;
GO

-- 5. Cập nhật giá mặt hàng (Có tham số)
CREATE PROCEDURE sp_CapNhatGiaMatHang
    @MaMH INT,
    @GiaMoi DECIMAL(10,2)
AS
BEGIN
    UPDATE MatHang SET DonGia = @GiaMoi WHERE MaMH = @MaMH;
END;
GO

-- 6. Xóa đơn đặt hàng theo mã (Có tham số)
CREATE PROCEDURE sp_XoaDonDatHang
    @SoDDH INT
AS
BEGIN
    DELETE FROM DonDatHang WHERE SoDDH = @SoDDH;
END;
GO

-- 7. Tính tổng giá trị một đơn hàng (Có tham số OUTPUT)
CREATE PROCEDURE sp_TinhTongGiaTriDonHang
    @SoDDH INT,
    @TongGiaTri DECIMAL(10,2) OUTPUT
AS
BEGIN
    SELECT @TongGiaTri = SUM(SoLuongDat * DonGiaDat)
    FROM ChiTietDatHang
    WHERE SoDDH = @SoDDH;
END;
GO

-- 8. Lấy danh sách đơn hàng chưa giao đủ (Không tham số)
CREATE PROCEDURE sp_DonHangChuaGiaoDu
AS
BEGIN
    SELECT ctdh.SoDDH, SUM(ctdh.SoLuongDat) AS TongDat, SUM(ctgh.SoLuongGiao) AS TongGiao
    FROM ChiTietDatHang ctdh
    LEFT JOIN ChiTietGiaoHang ctgh ON ctdh.MaMH = ctgh.MaMH
    GROUP BY ctdh.SoDDH
    HAVING SUM(ctgh.SoLuongGiao) < SUM(ctdh.SoLuongDat);
END;
GO

-- 9. Lấy danh sách đơn hàng theo tháng (Có tham số)
CREATE PROCEDURE sp_LayDonHangTheoThang
    @Thang INT,
    @Nam INT
AS
BEGIN
    SELECT * FROM DonDatHang 
    WHERE MONTH(NgayDat) = @Thang AND YEAR(NgayDat) = @Nam;
END;
GO

-- 10. Tìm nhà cung cấp có tổng giá trị đặt hàng cao nhất (Không tham số)
CREATE PROCEDURE sp_NhaCungCapGiaTriCaoNhat
AS
BEGIN
    SELECT TOP 1 d.MaNCC, n.TenNCC, SUM(ct.SoLuongDat * ct.DonGiaDat) AS TongGiaTri
    FROM DonDatHang d
    INNER JOIN NhaCungCap n ON d.MaNCC = n.MaNCC
    INNER JOIN ChiTietDatHang ct ON d.SoDDH = ct.SoDDH
    GROUP BY d.MaNCC, n.TenNCC
    ORDER BY SUM(ct.SoLuongDat * ct.DonGiaDat) DESC;
END;
GO
