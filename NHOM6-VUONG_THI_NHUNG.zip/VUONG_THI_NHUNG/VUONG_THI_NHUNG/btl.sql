create table NhaCungCap (
    MaNCC int primary key,
    TenNCC nvarchar(100),
    DiaChi nvarchar(255),
    DienThoai varchar(15)
);
create table MatHang (
    MaMH int primary key,
    TenMH nvarchar(100),
    DonViTinh nvarchar(50),
    QuyCach nvarchar(255),
    SoLuongTon int
);
create table DonDatHang (
    SoDDH int primary key,
    NgayDat date,
    MaNCC int,
    GhiChu nvarchar(255),
    foreign key (MaNCC) references NhaCungCap(MaNCC)
);
create table ChiTietDatHang (
    SoDDH int,
    MaMH int,
    SoLuongDat int,
    DonGiaDat decimal(18,2),
    primary key (SoDDH, MaMH),
    foreign key (SoDDH) references DonDatHang(SoDDH),
    foreign key (MaMH) references MatHang(MaMH)
);
create table PhieuGiaoHang (
    SoPGH int primary key,
    NgayGiao date,
    SoDDH INT,
    foreign key (SoDDH) references DonDatHang(SoDDH)
);
create table ChiTietGiaoHang (
    SoPGH int,
    MaMH int,
    SoLuongGiao int,
    DonGiaGiao decimal(18,2),
    primary key (SoPGH, MaMH),
    foreign key (SoPGH) references PhieuGiaoHang(SoPGH),
    foreign key (MaMH) references MatHang(MaMH)
);
