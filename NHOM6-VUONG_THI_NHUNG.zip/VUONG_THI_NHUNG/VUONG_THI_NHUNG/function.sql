﻿use DatGiaoHang
-- Hàm trả về tổng giá trị của một đơn đặt hàng
CREATE FUNCTION fn_TongGiaTriDonHang(@SoDDH INT) 
RETURNS DECIMAL(18,2)
AS
BEGIN
    DECLARE @TongGiaTri DECIMAL(18,2);
    SELECT @TongGiaTri = SUM(SoLuongDat * DonGiaDat)
    FROM ChiTietDatHang
    WHERE SoDDH = @SoDDH;
    RETURN @TongGiaTri;
END;

-- Hàm trả về số lượng mặt hàng của một nhà cung cấp
CREATE FUNCTION fn_SoLuongMatHangCungCap(@MaNCC INT) 
RETURNS INT
AS
BEGIN
    DECLARE @SoLuong INT;
    SELECT @SoLuong = COUNT(DISTINCT MaMH) 
    FROM MatHang 
    WHERE MaNCC = @MaNCC;
    RETURN @SoLuong;
END;
