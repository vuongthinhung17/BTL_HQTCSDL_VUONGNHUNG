﻿-- 1️⃣ Truy vấn Cơ bản (SELECT, INSERT, UPDATE, DELETE)

-- 1.1 Lấy danh sách nhà cung cấp
select  * from NhaCungCap;

-- 1.2 Thêm một mặt hàng mới
insert into MatHang (MaMH, TenMH, DonViTinh, QuyCach, SoLuongTon) 
values (5, 'Sản phẩm Z', 'Thùng', 'Thùng 20 chai', 30);

-- 1.3 Cập nhật số lượng tồn kho của một mặt hàng
update MatHang 
set SoLuongTon = SoLuongTon + 10
where MaMH = 1;

-- 1.4 Xóa một đơn đặt hàng
delete from DonDatHang 
where SoDDH = 1002;

-- 2️⃣ Truy vấn Nâng cao (INNER JOIN, GROUP BY, HAVING, SUBQUERY)

-- 2.1 Lấy danh sách đơn đặt hàng và thông tin nhà cung cấp
select ddh.SoDDH, ddh.NgayDat, ncc.TenNCC, ncc.DiaChi 
from DonDatHang ddh
inner join NhaCungCap ncc on ddh.MaNCC = ncc.MaNCC;

-- 2.2 Tính tổng số lượng hàng được đặt theo từng mặt hàng
select mh.TenMH, sum(ctdh.SoLuongDat) as TongSoLuongDat
from ChiTietDatHang ctdh
inner join MatHang mh on ctdh.MaMH = mh.MaMH
group by mh.TenMH;

-- 2.3 Lọc các mặt hàng có tổng số lượng đặt hàng lớn hơn 10
select mh.TenMH, sum(ctdh.SoLuongDat) as TongSoLuongDat
from ChiTietDatHang ctdh
inner join MatHang mh on ctdh.MaMH = mh.MaMH
group by mh.TenMH
having sum(ctdh.SoLuongDat) > 10;

-- 2.4 Lấy danh sách đơn hàng chưa có phiếu giao hàng
select SoDDH, NgayDat
from DonDatHang
where SoDDH not in (select SoDDH from PhieuGiaoHang);
