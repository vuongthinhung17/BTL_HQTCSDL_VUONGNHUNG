﻿-- 1️ Thêm Nhà Cung Cấp còn thiếu
insert into NhaCungCap (MaNCC, TenNCC, DiaChi, DienThoai) values
(3, 'Công ty C', 'Đà Nẵng', '0345678912'),
(4, 'Công ty D', 'Hải Phòng', '0456789123');

-- 2️ Thêm Đơn Đặt Hàng
insert into DonDatHang (SoDDH, NgayDat, MaNCC, GhiChu) values
(1001, '2024-03-01', 1, 'Đơn hàng tháng 3' ),
(1002, '2024-03-05', 2, 'Hàng tồn kho bổ sung'),
(1003, '2024-03-10', 3, 'Đặt hàng đợt đầu'),
(1004, '2024-03-15', 4, 'Hàng gấp cho dự án');

-- 3️ Thêm Chi Tiết Đặt Hàng
insert into ChiTietDatHang (SoDDH, MaMH, SoLuongDat, DonGiaDat) values
(1001, 1, 10, 1500000),
(1001, 2, 20, 700000),
(1002, 1, 5, 2500000),
(1002, 2, 3, 5000000),
(1003, 1, 8, 1400000),
(1003, 2, 4, 4800000),
(1004, 2, 5, 14500000);

-- 4️ Thêm Phiếu Giao Hàng
insert into PhieuGiaoHang (SoPGH, NgayGiao, SoDDH) values
(2001, '2024-03-03', 1001),
(2002, '2024-03-06', 1002),
(2003, '2024-03-12', 1003),
(2004, '2024-03-16', 1004);

-- 5️ Thêm Chi Tiết Giao Hàng
insert into ChiTietGiaoHang (SoPGH, MaMH, SoLuongGiao, DonGiaGiao) values
(2001, 1, 10, 1500000),
(2001, 2, 20, 700000),
(2002, 1, 5, 2500000),
(2002, 2, 3, 5000000),
(2003, 1, 8, 1400000),
(2003, 2, 4, 4800000),
(2004, 2, 5, 14500000);
