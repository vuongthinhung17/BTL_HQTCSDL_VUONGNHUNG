﻿use DatGiaoHang
--1. Index hỗ trợ truy vấn đơn đặt hàng theo ngày
CREATE INDEX idx_DonDatHang_NgayDat 
ON DonDatHang (NgayDat);
--2. Index hỗ trợ tìm kiếm sản phẩm theo tên
CREATE INDEX idx_MatHang_TenMH 
ON MatHang (TenMH);
--3. Index hỗ trợ truy vấn đơn hàng có giá trị lớn nhất
CREATE INDEX idx_ChiTietDatHang_DonGiaDat 
ON ChiTietDatHang (DonGiaDat);
--4. Index hỗ trợ truy vấn nhà cung cấp theo tên
CREATE INDEX idx_NhaCungCap_TenNCC 
ON NhaCungCap (TenNCC);
--5. Index trên bảng giao hàng để tìm kiếm theo mã đơn đặt hàng
CREATE INDEX idx_PhieuGiaoHang_SoDDH 
ON PhieuGiaoHang (SoDDH);
--6. Index tổng hợp trên nhiều cột (Composite Index)
CREATE INDEX idx_ChiTietDatHang_MaMH_DonGiaDat 
ON ChiTietDatHang (MaMH, DonGiaDat);
--7. Index hỗ trợ tìm kiếm đơn hàng có tổng số lượng đặt lớn hơn X
CREATE INDEX idx_ChiTietDatHang_SoLuongDat 
ON ChiTietDatHang (SoLuongDat);
--8. Index trên địa chỉ nhà cung cấp (Full-text Search nếu cần)
CREATE INDEX idx_NhaCungCap_DiaChi 
ON NhaCungCap (DiaChi);
