﻿use DatGiaoHang
-- Trigger kiểm tra số lượng hàng tồn trước khi đặt hàng
CREATE TRIGGER trg_Check_Stock_Before_Insert 
ON ChiTietDatHang
AFTER INSERT
AS
BEGIN
    IF EXISTS (
        SELECT 1 
        FROM inserted i
        JOIN MatHang MH ON i.MaMH = MH.MaMH
        WHERE i.SoLuongDat > MH.SoLuongTon
    )
    BEGIN
        RAISERROR ('Số lượng đặt vượt quá số lượng tồn kho!', 16, 1);
        ROLLBACK;
    END;
END;

-- Trigger cập nhật số lượng tồn kho khi giao hàng
CREATE TRIGGER trg_Update_Stock_After_Delivery
ON ChiTietGiaoHang

AFTER INSERT
AS
BEGIN
    UPDATE MatHang
    SET SoLuongTon = SoLuongTon - (SELECT SUM(i.SoLuongGiao) FROM inserted i WHERE i.MaMH = MatHang.MaMH)
    WHERE MaMH IN (SELECT MaMH FROM inserted);
END;

